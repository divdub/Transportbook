---
name: Fleet Operational Design System
colors:
  surface: '#faf8ff'
  surface-dim: '#d9d9e4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3fd'
  surface-container: '#ededf8'
  surface-container-high: '#e7e7f2'
  surface-container-highest: '#e1e2ec'
  on-surface: '#191b23'
  on-surface-variant: '#434654'
  inverse-surface: '#2e3038'
  inverse-on-surface: '#f0f0fb'
  outline: '#737685'
  outline-variant: '#c3c6d6'
  surface-tint: '#0c56d0'
  primary: '#003d9b'
  on-primary: '#ffffff'
  primary-container: '#0052cc'
  on-primary-container: '#c4d2ff'
  inverse-primary: '#b2c5ff'
  secondary: '#5e4db9'
  on-secondary: '#ffffff'
  secondary-container: '#9f8eff'
  on-secondary-container: '#341d8d'
  tertiary: '#7b2600'
  on-tertiary: '#ffffff'
  tertiary-container: '#a33500'
  on-tertiary-container: '#ffc6b2'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2ff'
  primary-fixed-dim: '#b2c5ff'
  on-primary-fixed: '#001848'
  on-primary-fixed-variant: '#0040a2'
  secondary-fixed: '#e5deff'
  secondary-fixed-dim: '#c9bfff'
  on-secondary-fixed: '#1a0063'
  on-secondary-fixed-variant: '#4633a0'
  tertiary-fixed: '#ffdbcf'
  tertiary-fixed-dim: '#ffb59b'
  on-tertiary-fixed: '#380d00'
  on-tertiary-fixed-variant: '#812800'
  background: '#faf8ff'
  on-background: '#191b23'
  surface-variant: '#e1e2ec'
typography:
  display-metrics:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  metadata:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 16px
  margin-mobile: 16px
---

## Brand & Style
The design system is engineered for high-utility, B2B fleet management environments where clarity and speed of data consumption are paramount. The brand personality is professional, systematic, and reliable. 

The aesthetic follows a **Modern Corporate Minimalism** approach. It prioritizes information density without clutter, utilizing a white-label SaaS feel that builds trust with enterprise logistics partners. The UI avoids decorative elements, focusing instead on functional clarity, high-contrast status indicators, and a rigorous adherence to systematic alignment. The emotional response should be one of "controlled efficiency"—users should feel they are using a robust tool designed for high-stakes operational monitoring.

## Colors
The palette is rooted in industry-standard professional tones. 
- **Primary Blue (#0052CC)**: Used for primary actions, active navigation states, and brand identifiers.
- **Secondary Purple (#6554C0)**: Reserved specifically for analytics, data visualization, and differentiating secondary metrics from operational tasks.
- **Neutral Scale**: The background uses a cool gray to reduce screen glare during long shifts, while surfaces remain white to create clear containment for data.
- **Semantic Colors**: Success, Warning, and Danger colors are calibrated for high legibility against white surfaces, ensuring "At-A-Glance" status checks for fleet health.

## Typography
This design system utilizes **Inter** for its neutral, highly legible characteristic on mobile screens. 
- **Metrics & Totals**: Use `display-metrics` for high-level dashboard figures (e.g., total active vehicles).
- **Headings**: Use `headline-md` for card titles and section headers.
- **Data Tables/Lists**: Use `body-md` for standard list items and `metadata` for timestamps or secondary ID strings.
- **Labels**: Use `label-md` with uppercase styling for small status badges or category headers to provide visual contrast without increasing size.

## Layout & Spacing
The system follows a strict **8pt grid system**. 
- **Margins**: Mobile layouts must maintain a 16px (2x base) safe area on the left and right edges.
- **Gutters**: Vertical spacing between cards or list items should be 8px or 12px to maintain a high information density suitable for enterprise tools.
- **Alignment**: All icons and text elements must align to the 4px baseline grid for precision.
- **Structure**: Use a single-column layout for mobile lists, switching to 2-column "stats grids" only for high-level summary dashboards.

## Elevation & Depth
To maintain a clean and professional aesthetic, this design system avoids heavy shadows and floating effects. 
- **Surface Layering**: Depth is primarily communicated through color contrast (White cards on a #F4F5F7 background).
- **Outlines**: Elements like input fields and inactive cards use a 1px solid border (#DFE1E6) rather than shadows.
- **Elevation**: A single, very subtle shadow level is permitted for "active" elements or bottom sheets: `0px 2px 4px rgba(9, 30, 66, 0.08)`.
- **Interactive States**: Buttons and clickable cards do not "lift" on press; instead, they utilize a subtle overlay or darken the background color to indicate a tap.

## Shapes
The shape language is "Soft" yet geometric. 
- **Standard Radius**: 8px (0.5rem) is the default for buttons, input fields, and cards.
- **Large Radius**: 12px (0.75rem) is used for major container sections or modals.
- **Small Radius**: 4px (0.25rem) is used for status tags and badges.
Avoid pill-shaped buttons; rectangular shapes with subtle rounding reinforce the professional, utilitarian nature of the fleet management tool.

## Components
- **Buttons**: Primary buttons are solid Blue (#0052CC) with White text. Secondary buttons use a subtle gray stroke. Use 16px horizontal padding and 12px vertical padding.
- **Status Chips**: Used for vehicle status (e.g., "In Transit", "Maintenance"). These use a light tinted background of the semantic color with high-contrast text (e.g., Success Green text on 10% Green background).
- **Cards**: Cards are the primary container. They should be flat with a 1px border. No shadows unless the card is being dragged or reordered.
- **Lists**: Fleet items should use a "Condensed List" format with a 40px lead icon or vehicle thumbnail, a primary title, and secondary metadata below it.
- **Input Fields**: Use a "Label-above" pattern. Borders are #DFE1E6 by default, turning Primary Blue on focus. Error states use the Danger Red color for the border and a small helper text below.
- **Icons**: Use geometric line icons (1.5px stroke width). Icons should always be centered within a 24px or 40px bounding box to maintain alignment across the grid.